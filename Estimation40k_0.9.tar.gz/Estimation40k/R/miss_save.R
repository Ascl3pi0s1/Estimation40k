miss_save <-
function(bless,svg){rbinom(1,bless,(svg-1)/6)}
