JetTot <-
function(Nb_attack,CT,rrTouch=0,mod_Touch=0,Bless_auto=7,For,End,rrBless=0,mod_Bless=0,Transu=0,dmg,Pv,svg,fnp=7){
  FNP(fnp,miss_save(jet_de_bless(JetTouch = jet_de_touche(Nb_attack =  Nb_attack,CT = CT,rrTouch =  rrTouch,mod_Touch =  mod_Touch,Bless_auto =Bless_auto),For =  For,End = End,rrBless=rrBless,mod_Bless = mod_Bless, Transu = Transu),svg),dmg,Pv,save)
}
